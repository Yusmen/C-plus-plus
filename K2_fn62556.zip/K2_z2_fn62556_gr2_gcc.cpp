
// Yusmen Zabanov 62556

#include <iostream>

using namespace std;
int SumOfDigitsOfAllNumbers(int arr[100], int N);
int main()
{
	int N ;
	cin >> N;
	int arr[100];
	for (int i = 0; i < N; i++)
	{
		cin >> arr[i];
	}
	cout << SumOfDigitsOfAllNumbers(arr, N) << endl;

}

int SumOfDigitsOfAllNumbers(int arr[100], int N)
{
	if (N == 0)
	{
		return 0;
	}
	int sum = 0;
	int number = arr[N - 1];
	while (number > 0)
	{
		sum += number % 10;
		number = number / 10;
	}
	--N;
	return sum + SumOfDigitsOfAllNumbers(arr, N);

}


