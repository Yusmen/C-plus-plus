
//Yusmen Zabanov 62556

#include <iostream>

using namespace std;
bool SumOfDigitsEqualToFirstTwo(int number);
int main()
{
	int number;
	cin >> number;
	cout << SumOfDigitsEqualToFirstTwo(number)<<endl;

}
bool SumOfDigitsEqualToFirstTwo(int number)
{
	int sumDigits = 0, m;

	
	double tempNumber = number;
	while (number > 0)
	{
		m = number % 10;
		sumDigits = sumDigits + m;
		number = number / 10;
	}


	while (tempNumber > 1)
	{
		tempNumber /= 10;

	}
	tempNumber *= 100;
	int numberForEqual = (int)tempNumber;


	if (numberForEqual == sumDigits)
	{
		return true;

	}
	return false;
}


